import React,{ Component } from 'react';

class Experience extends Component{
    render(){
        return (

                <div className='container'>
                    <div className='row'>
                        <div style={{display: "flex",justifyContent: "center",alignItems: "center"}}>
                        <h2>__________  WORK EXPERIENCE  _________</h2></div><br/>
                        <div style={{ display: "flex",justifyContent: "Left"}}>May 2020 - Present &nbsp; 
                     Slack Upskilling Community Manager 
                      SKILLSANTA
                       Manage Slack channel. Solve doubts of students and Posts quizzes and assignment.</div>
                       <div style={{display: "flex",justifyContent: "Left",alignItems: "center"       
                        }}> May 2020 - July 2020 &nbsp;                        
                         Backend Development Intern GIRLSCRIPT FOUNDATION 
                    Built REST APIs for E-learning platform in Node.js, Express.js and MongoDB</div>
                    </div>  
                </div>                    
        );
    }
}

export default Experience;


