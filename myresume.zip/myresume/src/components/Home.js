import React,{ Component } from 'react';
import './styles.css';

class Home extends Component{
    render(){
        return (            
                <div >
                    <div >
                        <div className="center">
                            <h1>Resume</h1><br/>Raushan Kumar
                        </div> 
                    </div>
                </div>                    
        );
    }
}
export default Home;


