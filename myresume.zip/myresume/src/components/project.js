import React,{ Component } from 'react';

class Project extends Component{
    render(){
        return (          
            <div className='container'>
            <div className='row'>
                <div className="center">
                <h2>__________  Project  _________</h2></div><br/>
                <div style={{ display: "flex",justifyContent: "Left"}}>TASKIFY APPLICATION&nbsp;&nbsp;&nbsp; An application build in Node.js, Express.js and MongoDB. It stores tasks of the user. It has login and signup functionality. User can create, read, update and delete tasks.</div>
               <div style={{display: "flex",justifyContent: "Left"}}>YOUTUBE DOWNLOADER&nbsp;&nbsp;&nbsp; A desktop application built using Tkinter. It can download youtube video in high or low quality on entered URL.</div> 
                </div>                 
            </div>    
        );
    }
}

export default Project;


