import React,{ Component } from 'react';

class Profile extends Component{
    render(){
        return (
        
            
                <div>
                    <div className='row'>
                        <div className='col s15 m4 13'></div>
                        <h2>____________ EDUCATION _____________</h2>
                        <div className='col s15 m8 19'></div>
                        
                        <div style={{ display: "flex",justifyContent: "Left"}}>2018-2022 &nbsp;

SHARDA UNIVERSITY, Greater Noida, India
B.Tech, Computer Science & Engineering
GPA: 9.583

2015-2018

G. P. G. COLLEGE, Bihar, India
Intermediate
Percentage: 64.8

2015

D. A. V. PUBLIC SCHOOL, Bihar, India
High School
CGPA: 8.8</div>
                       <div style={{display: "flex",justifyContent: "Left",alignItems: "center"       
                        }}> May 2020 - July 2020 &nbsp;                        
                         Backend Development Intern GIRLSCRIPT FOUNDATION 
                    Built REST APIs for E-learning platform in Node.js, Express.js and MongoDB</div>
                    </div>  
                </div>            
        );
    }
}

export default Profile;

