import React,{ Component } from 'react';

class Skills extends Component{
    render(){
        return (          
            <div className='container'>
            <div className='row'>
                <div className="center">
                <h2>__________  Skills  _________</h2></div><br/>
                <div style={{ display: "flex",justifyContent: "Left"}}>May 2020 - Present &nbsp;&nbsp;&nbsp; Slack Upskilling Community Manager 
              SKILLSANTA               Manage Slack channel. Solve doubts of students and Posts quizzes and assignment.</div>  <br/>
                        
               <div style={{display: "flex",justifyContent: "Left"}}> May 2020 - July 2020 &nbsp;&nbsp;&nbsp; Backend Development Intern GIRLSCRIPT FOUNDATION 
            Built REST APIs for E-learning platform in Node.js, Express.js and MongoDB </div> 
                </div>                 
            </div>    
        );
    }
}

export default Skills;


