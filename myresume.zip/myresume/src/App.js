import React from 'react';

import './App.css';
import Home from './components/Home';
import Skills from './components/Skills';
import Profile from './components/Profile';
import Experience from './components/Experience';
import Project from './components/project';
function App() {
  return (
    <div className="App">
      
      <div className='container'>
      <Home/>
      <Skills/>
      <Experience/>
      <Profile/>
      <Project/>
      </div>
    </div>
  );
}

export default App;
